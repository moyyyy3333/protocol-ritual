# 🍽️ Restaurant AI Bot — Dallas Edition

A gift from Morpheus 🤝

## What This Does

This bot finds restaurants in **Dallas** that don't have websites (or have terrible ones), builds them a professional mobile-optimized website with click-to-call ordering, and emails/SMS the owners asking if they want to buy it for **$299**.

## The System in Plain English

**Step 1: Scan**
The bot searches Google Maps for restaurants in Dallas neighborhoods. It checks if they have a website. If they don't, it logs their name, phone, address, and rating.

**Step 2: Build**
For every lead, it generates a full restaurant website with:
- Their restaurant name, phone, address
- A menu with real food items (matched to their cuisine type)
- Click-to-call ordering button
- Hours of operation
- Anti-copy protection (can't screenshot, print, or steal the design)
- 72-hour demo watermark

**Step 3: Host**
Sites are uploaded to GitHub Pages — free hosting, permanent links.

**Step 4: Reach Out**
Two ways to contact restaurant owners:
- **SMS (text messages)** — sends from your Mac's iMessage (free but uses your number)
- **Email** — via Yahoo SMTP with app password

**Step 5: Close**
When an owner replies "yes," send them a $299 invoice. They get the site permanently.

---

## 📋 What You Need Before Starting

| Item | Free? | Where to Get |
|------|-------|-------------|
| GitHub account | ✅ Free | github.com |
| Google Cloud account | ✅ $200 free credit | console.cloud.google.com |
| Yahoo email | ✅ Free | yahoo.com |
| A Mac (for SMS) | 💰 You have one | — |
| GitHub Pages | ✅ Free | Automatic |

---

## 🚀 Setup Instructions (30 minutes)

### 1. Get a Google Places API Key

1. Go to **https://console.cloud.google.com**
2. Create a new project → "Restaurant Bot"
3. Go to **APIs & Services** → **Library**
4. Search "Places API" → **Enable**
5. Go to **Credentials** → **Create Credentials** → **API Key**
6. Copy the key (looks like `AIzaSy...`)

### 2. Get a Yahoo App Password (for email)

1. Go to **https://login.yahoo.com** → Account Security
2. Turn on **2-Step Verification** (if not already on)
3. Go to **App Passwords**
4. Generate one for "Mail" → copy the 16-character code

### 3. Fork/Clone the Code

```bash
git clone https://github.com/YOUR_USERNAME/restaurant-ai-bot.git
cd restaurant-ai-bot
```

### 4. Configure for Dallas

Open `config.py` and:
- Paste your Google API key
- Paste your Yahoo email + app password
- The `DALLAS_AREAS` list is already there (replaces Houston)

### 5. Run the Scanner

```bash
python3 scanner/scan_places_v2.py
```

This scans all Dallas neighborhoods and saves leads to the database.

### 6. Build Demo Sites

```bash
python3 generator.py
```

Generates HTML websites for every lead.

### 7. Send SMS (from Mac)

```bash
python3 sms_sender.py
```

This sends texts through your Mac's Messages app. **Authorize "node" to control Messages when prompted.**

### 8. Deploy on Railway (optional 24/7)

Put the code on **https://railway.com** for the Telegram bot version (auto-scans, auto-sends).

---

## 📁 File Guide

| File | What It Does |
|------|-------------|
| `scanner/scan_places_v2.py` | Searches Google Maps for no-website restaurants |
| `generator.py` | Builds HTML demo sites with menus, hours, protection |
| `sms_sender.py` | Texts leads their demo link via iMessage |
| `emailer.py` | Sends emails via Yahoo SMTP |
| `bot.py` | Telegram bot controller |
| `server.py` | Flask server for live site previews |
| `db.py` | SQLite database (stores leads, sites, logs) |
| `config.py` | API keys and Dallas area list |

---

## 💰 The Business Model

**Price per site: $299** (one-time, no monthly fees)

**Typical results (real data from Houston test):**
- 15 texts sent → expect 1-3 replies
- 1-2 replies → 1 close
- **1 sale = $299** on your first try
- **Scale to 50 texts/day** = $500-1,000/week

**Target:** Any small business without a proper website:
- Restaurants (tacos, pho, bbq, soul food)
- Food trucks
- Mechanics, barbers, laundromats
- Any local business on Google Maps

---

## 🔒 Protection Built In

Every generated site has:
- Anti-screenshot watermark ("PROTOCOL DEMO PREVIEW")
- Right-click blocked
- Print blocked
- Copy/paste blocked
- DevTools detection
- Iframe embedding blocked
- 72-hour demo expiry (in the Telegram bot version)

The customer pays → you remove the protection → site goes live.

---

## 🆘 Need Help?

If anything breaks:
1. Check the logs: `cat sms_log.txt`
2. Check the database: `sqlite3 restaurant-bot.db "SELECT * FROM restaurants"`
3. Text Morpheus — he'll get Neo on it.

---

*Built by Neo 🕶️ — May 2026*
