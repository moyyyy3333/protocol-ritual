# ============================================
# RESTAURANT AI BOT — DALLAS EDITION
# Edit these values for your city
# ============================================

# === Google Places API ===
# Get yours at: https://console.cloud.google.com
# Enable "Places API" in your project
GOOGLE_PLACES_API_KEY = "YOUR_GOOGLE_API_KEY_HERE"

# === Yahoo SMTP (for sending emails) ===
# Generate an app password at: https://login.yahoo.com -> Account Security -> App Passwords
YAHOO_EMAIL = "your_email@yahoo.com"
YAHOO_APP_PASSWORD = "your_app_password_here"

# === Your Phone Number ===
YOUR_PHONE = "+1XXX555XXXX"

# === Scan Areas (Dallas neighborhoods) ===
# Edit this list for your city!
SCAN_AREAS = [
    "Deep Ellum", "Bishop Arts", "Uptown Dallas", "Downtown Dallas",
    "Lower Greenville", "Knox-Henderson", "Oak Lawn", "Design District",
    "West Village", "Trinity Groves", "Preston Hollow", "Lakewood",
    "Oak Cliff", "Cedar Springs", "Mockingbird Station", "Highland Park",
    "Richardson", "Plano", "Garland", "Irving",
    "Farmers Branch", "Carrollton", "Addison", "Frisco"
]

# === Database ===
DATABASE_URL = "sqlite:///restaurant-bot.db"

# === Demo Settings ===
DEMO_BASE_URL = "http://localhost:8080"
DEMO_EXPIRE_HOURS = 72
