#!/usr/bin/env python3
"""Send SMS demo links via Mac iMessage"""
import subprocess, sqlite3, time
from datetime import datetime

DB_PATH = 'restaurant-bot.db'
LOG_PATH = 'sms_log.txt'

def send_sms(phone, msg):
    escaped = msg.replace('"', '\\"')
    script = f'''tell application "Messages" to send "{escaped}" to buddy "{phone}"'''
    try:
        r = subprocess.run(['osascript', '-e', script], capture_output=True, text=True, timeout=30)
        return r.returncode == 0, r.stderr
    except:
        return False, "timeout"

# Get leads with real phones
conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
rows = conn.execute("""
    SELECT r.name, r.phone
    FROM restaurants r
    WHERE r.has_website = 0 AND r.phone IS NOT NULL AND r.phone != '' AND r.phone NOT LIKE '%555%'
    ORDER BY r.rating DESC
""").fetchall()
conn.close()

print(f"📱 {len(rows)} leads ready to text\n")

# Send in batches of 5
for i, r in enumerate(rows[:5], 1):
    name = r['name']
    phone = r['phone']
    
    msg = f"Hi, we built your restaurant a free website demo. Reply YES for the link."
    
    print(f"[{i}/5] {name[:35]}... ", end="", flush=True)
    success, err = send_sms(phone, msg)
    
    ts = datetime.now().strftime('%H:%M:%S')
    if success:
        print(f"✅ {phone}")
        with open(LOG_PATH, 'a') as f:
            f.write(f"[{ts}] ✅ {name} — {phone}\n")
    else:
        print(f"❌ {err[:50]}")
    
    if i < 5:
        time.sleep(8)

print(f"\nDone! Check Messages app for replies.")
