# ============================================
# 🎁 MATTHEW OPDENHOFF — RESTAURANT AI BOT
# Miami Edition
# Edit these values for your city
# ============================================

# === Google Places API ===
# Get yours at: https://console.cloud.google.com
# Enable "Places API" in your project
GOOGLE_PLACES_API_KEY = "***"

# === Yahoo SMTP (for sending emails) ===
YAHOO_EMAIL = "your_email@yahoo.com"
YAHOO_APP_PASSWORD = "***"

# === Your Phone Number ===
YOUR_PHONE = "+1XXX555XXXX"

# === Scan Areas (Miami neighborhoods) ===
SCAN_AREAS = [
    "South Beach", "Downtown Miami", "Brickell", "Coral Gables",
    "Coconut Grove", "Key Biscayne", "Wynwood", "Design District",
    "Little Havana", "Midtown Miami", "Edgewater", "Hialeah",
    "Miami Beach", "North Miami", "Kendall", "Doral",
    "Fort Lauderdale", "Hollywood", "Pembroke Pines", "Miramar",
    "Coral Springs", "West Palm Beach", "Boca Raton", "Delray Beach"
]

# === Database ===
DATABASE_URL = "sqlite:///restaurant-bot.db"

# === Demo Settings ===
DEMO_BASE_URL = "http://localhost:8080"
DEMO_EXPIRE_HOURS = 72
