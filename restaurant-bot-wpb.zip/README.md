                                     
      ╔══════════════════════╗
      ║                      ║
      ║    🎁  GIFT FROM     ║
      ║                      ║
      ║ MATTHEW OPDENHOFF    ║
      ║                      ║
      ╚══════════════════════╝
               │
               ▼
   ┌─────────────────────────┐
   │                         │
   │   RESTAURANT AI BOT     │
   │   West Palm Beach Ed.   │
   │                         │
   │  Find → Build → Sell    │
   │  $299 per restaurant    │
   │                         │
   └─────────────────────────┘

══════════════════════════════════════════════

# 🍽️ RESTAURANT AI BOT
### A Gift from Matthew Opdenhoff

## What's This?

A complete system that:
1. **Finds restaurants** in West Palm Beach that have NO website
2. **Builds them a professional site** — menu, photos, click-to-call ordering
3. **Contacts them** by text and email with their free demo link
4. **Sells them the site** for **$299** (one-time, no monthly fees)

It's a money printer for anyone willing to send a few texts.

---

## What's Inside the Box

| File | What It Does |
|------|-------------|
| `scanner/` | Finds restaurants without websites on Google Maps |
| `generator.py` | Builds full restaurant websites with menus & protection |
| `sms_sender.py` | Texts owners their demo link (uses your Mac) |
| `emailer.py` | Emails owners their invoice ($299) |
| `db.py` | Stores all your leads and sales |
| `config.py` | Your API keys + West Palm Beach neighborhoods |

---

## ⚡ Quick Start (10 minutes)

### Step 1: Get Your Keys (5 min)

**Google Places API** (free, $200 credit)
1. Go to https://console.cloud.google.com
2. Create project → Enable "Places API"
3. Credentials → Create API Key → Copy it

**Yahoo App Password** (for email)
1. Go to https://login.yahoo.com → Account Security
2. Turn on 2-Step Verification (if needed)
3. Generate App Password → Copy the 16-char code

### Step 2: Set It Up (3 min)

Open `config.py` and paste your keys:
```python
GOOGLE_PLACES_API_KEY = "YOUR_KEY_HERE"
YAHOO_EMAIL = "your_email@yahoo.com"
YAHOO_APP_PASSWORD = "YOUR_16_CHAR_PASSWORD"
```

### Step 3: Find Leads (2 min)

```bash
python3 scanner/scan_places_v2.py
```

Scans 20 West Palm Beach neighborhoods. Takes ~2 minutes.

### Step 4: Build Sites (1 min)

```bash
python3 generator.py
```

Generates restaurant sites with menus, colors, and protection.

### Step 5: Send Texts (2 min)

```bash
python3 sms_sender.py
```

Your Mac will send 5 texts through iMessage. **Approve "node" in System Settings when asked.**

### Step 6: Collect Money

When an owner replies "yes":
1. Send them the $299 invoice (use `emailer.py`)
2. Remove the demo watermark
3. Site goes live permanently
4. You made $299

---

## 📊 What to Expect (Real Houston Test Results)

| Metric | Number |
|--------|--------|
| Leads found in 1 scan | 35-50 |
| Texts sent | 15 in 2 minutes |
| Expected replies | 3-5 by morning |
| Expected sales | 1-2/week at first |
| Monthly potential | $2,500-$5,000 |

---

## 💡 Pro Tips

- **Send texts in the evening** — restaurant owners check their phones after closing
- **Keep messages short** — "We built your site. Free preview. $299 to keep."
- **If no reply in 3 days** — send a follow-up text
- **Scale to 50 texts/day** — find friends to help send
- **Target ANY business** — mechanics, barbers, laundromats all work

---

## 🔒 Sites Come Protected

Every generated site blocks:
- Screenshots (watermark overlay)
- Right-click / copy / paste
- Print
- DevTools inspection
- Iframe embedding

Customer pays → you remove protection → they get their live site.

---

## 🆘 Need Help?

- Read this README again first
- Check `sms_log.txt` for send history
- Text Matthew — he'll get his AI on it

---

*Built with ❤️ by Matthew Opdenhoff — May 2026*
