# ============================================
# 🎁 MATTHEW OPDENHOFF — RESTAURANT AI BOT
# West Palm Beach Edition
# Edit these values for your city
# ============================================

# === Google Places API ===
# Get yours at: https://console.cloud.google.com
# Enable "Places API" in your project
GOOGLE_PLACES_API_KEY = "YOUR_G…HERE"

# === Yahoo SMTP (for sending emails) ===
# Generate an app password at: https://login.yahoo.com -> Account Security -> App Passwords
YAHOO_EMAIL = "your_email@yahoo.com"
YAHOO_APP_PASSWORD = "your_a…here"

# === Your Phone Number ===
YOUR_PHONE = "+1XXX555XXXX"

# === Scan Areas (West Palm Beach neighborhoods) ===
# Edit this list for your city!
SCAN_AREAS = [
    "Downtown West Palm Beach", "Clematis Street", "CityPlace",
    "Palm Beach", "Lake Worth", "Delray Beach",
    "Boca Raton", "Boynton Beach", "Jupiter", "Wellington",
    "Royal Palm Beach", "Greenacres", "Lantana", "Riviera Beach",
    "North Palm Beach", "Palm Beach Gardens", "West Palm Beach",
    "Singer Island", "Manalapan", "Hypoluxo"
]

# === Database ===
DATABASE_URL = "sqlite:///restaurant-bot.db"

# === Demo Settings ===
DEMO_BASE_URL = "http://localhost:8080"
DEMO_EXPIRE_HOURS = 72
